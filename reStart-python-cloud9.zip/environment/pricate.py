name="venkatesh"
age=23
salary=10000
print ('my name is ' ,name, 'my age is ',age, 'my salary is' ,salary)
myvalue=5j
print(myvalue)
print(type(myvalue))
print (str(myvalue) +"is of the data type" + str(type(myvalue)))
myvalue=True
print(myvalue)
print(type(myvalue))
print (str(myvalue) + "is of the data type" + str(type(myvalue)))
myvalue=False
print(myvalue)
print(type(myvalue))
print (str(myvalue) + "is of the data type" + str(type(myvalue)))
myvalue="false"
print(myvalue)
print(type(myvalue))
print (str(myvalue) + "is of the data type" + str(type(myvalue)))