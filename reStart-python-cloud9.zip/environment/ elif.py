i=5
for i in range(11):
    print(a , 'x' ,i ,'=', a*i)
    