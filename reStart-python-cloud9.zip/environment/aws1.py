"""
Your module description
"""
name = venkatesh
print (name)
print ("my name is " ,name)
name="venkatesh"
print(name)
print ("my name is " ,name)
print ('my name is' ,name)
