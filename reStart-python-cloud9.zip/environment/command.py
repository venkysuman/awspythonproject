"""
Your module description
"""
userreply=input("do you need to ship a package? (enter yes or no) ")
if userreply == "yes":
    print("we can help you ship that package!")