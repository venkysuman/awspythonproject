userreply = input("would you like to buy stamps, buy an envelope, or make a copy? (enter stamps, envelope, or copy)")
if userreply == "stamps":
    print("we have many stamp designs to change feom.")
elif userreply == "envelope":
    print("we have many envelope sizes to choose from.")
elif userreply == "copy":
    copies = input("how many copies would ypu like? (enter a number) ")
    print("here are {} copies.".format(copies))
else:
    print("thank you, please come again.")
