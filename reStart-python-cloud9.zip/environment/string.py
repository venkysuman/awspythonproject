myString = "This ia a string"
print(myString)
print(type(myString))
print (str(myString) +  " is of the data type" + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + " " + secondString
print(thirdString)
n